/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-manager
 */

package app.morphe.manager.ui.screen.shared

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.graphics.createBitmap
import androidx.documentfile.provider.DocumentFile
import app.morphe.manager.R
import app.morphe.manager.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Configuration constants for header creation.
 */
private object HeaderConfig {
    // Folder structure
    const val BRANDING_FOLDER_NAME = "morphe_branding"
    const val YOUTUBE_HEADER_FOLDER_NAME = "morphe_header_youtube"
    const val YTM_HEADER_FOLDER_NAME = "morphe_header_music"

    // File names
    const val LIGHT_HEADER_FILE_NAME = "morphe_header_custom_light"
    const val DARK_HEADER_FILE_NAME = "morphe_header_custom_dark"

    fun headerFolderName(packageName: String) = when (packageName) {
        KnownApps.YOUTUBE_MUSIC -> YTM_HEADER_FOLDER_NAME
        else -> YOUTUBE_HEADER_FOLDER_NAME
    }

    // Density folders and sizes (width x height)
    val DENSITY_CONFIGS = mapOf(
        240 to ("drawable-hdpi" to (194 to 72)),
        320 to ("drawable-xhdpi" to (258 to 96)),
        480 to ("drawable-xxhdpi" to (387 to 144)),
        Int.MAX_VALUE to ("drawable-xxxhdpi" to (512 to 192))
    )

    // Transform constraints
    const val MIN_SCALE = 0.3f
    const val MAX_SCALE = 5.0f
    const val MAX_OFFSET = 300f

    // Snap to center thresholds (in pixels)
    const val SNAP_THRESHOLD = 10f
    const val SNAP_GUIDE_THRESHOLD = 15f

    // Visual appearance
    const val SNAP_GUIDE_ALPHA = 0.6f
    const val SNAP_GUIDE_STROKE_WIDTH = 1.5f
    const val BORDER_STROKE_WIDTH = 2f
}

/**
 * Dialog for creating custom headers with light and dark theme variants.
 * Generates header images in proper sizes for all screen densities.
 */
@Composable
fun HeaderCreatorDialog(
    packageName: String,
    onDismiss: () -> Unit,
    onHeaderCreated: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // YouTube Music has no light theme - show only the dark variant section
    val showLightVariant = packageName != KnownApps.YOUTUBE_MUSIC

    val light = remember { HeaderVariantState() }
    val dark = remember { HeaderVariantState() }

    val successMessage = stringResource(R.string.header_creator_success)
    val failureMessage = stringResource(R.string.header_creator_failed)

    // Whether all required images are provided
    val canCreate = dark.bitmap != null && (!showLightVariant || light.bitmap != null)

    var isCreating by remember { mutableStateOf(false) }

    // Folder picker for saving
    val openFolderPicker = rememberFolderPicker { uri ->
        scope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { isCreating = true }
            try {
                val success = createHeaderFiles(
                    context = context,
                    baseUri = uri,
                    packageName = packageName,
                    lightHeaderBitmap = if (showLightVariant) light.bitmap else null,
                    darkHeaderBitmap = dark.bitmap!!,
                    lightScale = light.scale,
                    lightOffsetX = light.offsetX,
                    lightOffsetY = light.offsetY,
                    darkScale = dark.scale,
                    darkOffsetX = dark.offsetX,
                    darkOffsetY = dark.offsetY
                )
                withContext(Dispatchers.Main) {
                    isCreating = false
                    if (success != null) {
                        context.toast(successMessage)
                        onHeaderCreated(success)
                        onDismiss()
                    } else {
                        context.toast(failureMessage)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isCreating = false
                    context.toast("Failed to create header: ${e.message}")
                }
            }
        }
    }

    CreatorDialogFrame(
        packageName = packageName,
        title = stringResource(R.string.header_creator_create),
        guideTitle = stringResource(R.string.header_creator_guide),
        guide = listOf(
            stringResource(R.string.header_creator_guide_image_title) to stringResource(R.string.header_creator_guide_image_body),
            stringResource(R.string.header_creator_guide_themes_title) to stringResource(R.string.header_creator_guide_themes_body),
            stringResource(R.string.header_creator_guide_positioning_title) to stringResource(R.string.header_creator_guide_positioning_body)
        ),
        createEnabled = canCreate,
        isCreating = isCreating,
        onCreate = { openFolderPicker() },
        onDismiss = onDismiss
    ) {
        if (showLightVariant) {
            HeaderVariantCard(
                title = stringResource(R.string.header_creator_light_theme),
                icon = Icons.Outlined.LightMode,
                state = light,
                isDarkTheme = false
            )
        }

        HeaderVariantCard(
            title = stringResource(R.string.header_creator_dark_theme),
            icon = Icons.Outlined.DarkMode,
            state = dark,
            isDarkTheme = true
        )
    }
}

/** One theme's header: the picture picked for it and where it sits in the header's frame. */
@Stable
private class HeaderVariantState {
    var bitmap by mutableStateOf<Bitmap?>(null)
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)

    val isTransformed: Boolean get() = scale != 1f || offsetX != 0f || offsetY != 0f

    fun resetTransform() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }
}

/**
 * Card of one theme's header: the picture to pick, its preview to pinch and drag into place, and
 * the scale slider once there is a picture to scale.
 */
@Composable
private fun HeaderVariantCard(
    title: String,
    icon: ImageVector,
    state: HeaderVariantState,
    isDarkTheme: Boolean
) {
    val openPicker = rememberImagePicker { bitmap ->
        state.bitmap = bitmap
        // Reset transform when new image is loaded
        state.resetTransform()
    }

    CreatorCard(title = title) {
        AppDialogOutlinedButton(
            text = stringResource(
                if (state.bitmap == null) R.string.adaptive_icon_select_image else R.string.adaptive_icon_change_image
            ),
            onClick = { openPicker() },
            icon = icon,
            modifier = Modifier.fillMaxWidth()
        )

        HeaderPreview(
            headerBitmap = state.bitmap,
            scale = state.scale,
            offsetX = state.offsetX,
            offsetY = state.offsetY,
            isDarkTheme = isDarkTheme,
            onScaleChange = { newScale ->
                state.scale = newScale.coerceIn(HeaderConfig.MIN_SCALE, HeaderConfig.MAX_SCALE)
            },
            onOffsetChange = { newOffsetX, newOffsetY ->
                state.offsetX = newOffsetX.coerceIn(-HeaderConfig.MAX_OFFSET, HeaderConfig.MAX_OFFSET)
                state.offsetY = newOffsetY.coerceIn(-HeaderConfig.MAX_OFFSET, HeaderConfig.MAX_OFFSET)
            }
        )

        if (state.bitmap != null) {
            ScaleSliderRow(
                value = state.scale,
                onValueChange = { state.scale = it },
                valueRange = HeaderConfig.MIN_SCALE..HeaderConfig.MAX_SCALE
            ) {
                SliderResetAction(
                    visible = state.isTransformed,
                    contentDescription = stringResource(R.string.adaptive_icon_reset_transform),
                    onReset = state::resetTransform
                )
            }
        }
    }
}

/**
 * Preview component for header with transform gestures.
 */
@Composable
private fun HeaderPreview(
    headerBitmap: Bitmap?,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    isDarkTheme: Boolean,
    onScaleChange: (Float) -> Unit,
    onOffsetChange: (Float, Float) -> Unit
) {
    val density = LocalConfiguration.current.densityDpi

    // Determine which size to use based on density
    val (_, targetSize) = HeaderConfig.DENSITY_CONFIGS
        .entries
        .firstOrNull { density <= it.key }
        ?.value
        ?: HeaderConfig.DENSITY_CONFIGS[Int.MAX_VALUE]!!

    val (targetWidth, targetHeight) = targetSize

    // Convert target size to dp for preview
    val previewWidth = targetWidth.dp
    val previewHeight = targetHeight.dp

    // Guide color
    val guideColor = if (isDarkTheme)
        Color.White.copy(alpha = HeaderConfig.SNAP_GUIDE_ALPHA)
    else
        Color.Black.copy(alpha = HeaderConfig.SNAP_GUIDE_ALPHA)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .width(previewWidth)
                .height(previewHeight)
                .clip(RoundedCornerShape(Defaults.CompactCornerRadius))
                .background(
                    if (isDarkTheme)
                        Color(0xFF1C1C1C)
                    else
                        Color(0xFFF5F5F5)
                )
                .border(
                    HeaderConfig.BORDER_STROKE_WIDTH.dp,
                    MaterialTheme.colorScheme.outline,
                    RoundedCornerShape(Defaults.CompactCornerRadius)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (headerBitmap != null) {
                var currentScale by remember { mutableFloatStateOf(scale) }
                var currentOffsetX by remember { mutableFloatStateOf(offsetX) }
                var currentOffsetY by remember { mutableFloatStateOf(offsetY) }

                // Sync with parent state
                LaunchedEffect(scale, offsetX, offsetY) {
                    currentScale = scale
                    currentOffsetX = offsetX
                    currentOffsetY = offsetY
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                // Apply zoom
                                currentScale *= zoom

                                // Apply pan
                                var newOffsetX = currentOffsetX + pan.x
                                var newOffsetY = currentOffsetY + pan.y

                                // Snap to center when close
                                if (abs(newOffsetX) < HeaderConfig.SNAP_THRESHOLD) newOffsetX = 0f
                                if (abs(newOffsetY) < HeaderConfig.SNAP_THRESHOLD) newOffsetY = 0f

                                currentOffsetX = newOffsetX
                                currentOffsetY = newOffsetY

                                // Update parent state
                                onScaleChange(currentScale)
                                onOffsetChange(currentOffsetX, currentOffsetY)
                            }
                        }
                ) {
                    val centerX = size.width / 2
                    val centerY = size.height / 2

                    // Draw header image
                    val imageBitmap = headerBitmap.asImageBitmap()

                    // Fit image to canvas while maintaining aspect ratio
                    val imageAspect = imageBitmap.width.toFloat() / imageBitmap.height.toFloat()
                    val canvasAspect = size.width / size.height

                    val (baseWidth, baseHeight) = if (imageAspect > canvasAspect) {
                        // Image is wider - fit to width
                        size.width to (size.width / imageAspect)
                    } else {
                        // Image is taller - fit to height
                        (size.height * imageAspect) to size.height
                    }

                    // Apply user scale
                    val displayWidth = baseWidth * currentScale
                    val displayHeight = baseHeight * currentScale

                    // Calculate position with offset
                    val left = centerX - (displayWidth / 2) + currentOffsetX
                    val top = centerY - (displayHeight / 2) + currentOffsetY

                    // Draw the image at actual size (will be cropped by canvas bounds)
                    drawImage(
                        image = imageBitmap,
                        dstOffset = IntOffset(left.toInt(), top.toInt()),
                        dstSize = IntSize(displayWidth.toInt(), displayHeight.toInt())
                    )

                    // Draw dashed snap guides when close to center
                    if (abs(currentOffsetX) < HeaderConfig.SNAP_GUIDE_THRESHOLD ||
                        abs(currentOffsetY) < HeaderConfig.SNAP_GUIDE_THRESHOLD) {

                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)

                        // Vertical center line
                        if (abs(currentOffsetX) < HeaderConfig.SNAP_GUIDE_THRESHOLD) {
                            drawLine(
                                color = guideColor,
                                start = Offset(centerX, 0f),
                                end = Offset(centerX, size.height),
                                strokeWidth = HeaderConfig.SNAP_GUIDE_STROKE_WIDTH,
                                pathEffect = dashEffect
                            )
                        }

                        // Horizontal center line
                        if (abs(currentOffsetY) < HeaderConfig.SNAP_GUIDE_THRESHOLD) {
                            drawLine(
                                color = guideColor,
                                start = Offset(0f, centerY),
                                end = Offset(size.width, centerY),
                                strokeWidth = HeaderConfig.SNAP_GUIDE_STROKE_WIDTH,
                                pathEffect = dashEffect
                            )
                        }
                    }
                }
            } else {
                // Empty state
                val placeholderColor = if (isDarkTheme) {
                    Color.White.copy(alpha = 0.6f)
                } else {
                    Color.Black.copy(alpha = 0.6f)
                }

                Text(
                    text = stringResource(R.string.header_creator_no_image),
                    style = MaterialTheme.typography.bodySmall,
                    color = placeholderColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.Center)
                )
            }
        }
    }
}

/**
 * Create header files in proper structure.
 * [lightHeaderBitmap] is null when the light variant is not needed (e.g. YouTube Music).
 * Returns the path to morphe_header folder or null if failed.
 */
private suspend fun createHeaderFiles(
    context: Context,
    baseUri: Uri,
    packageName: String,
    lightHeaderBitmap: Bitmap?,
    darkHeaderBitmap: Bitmap,
    lightScale: Float,
    lightOffsetX: Float,
    lightOffsetY: Float,
    darkScale: Float,
    darkOffsetX: Float,
    darkOffsetY: Float
): String? = withContext(Dispatchers.IO) {
    try {
        // Get current device density
        val displayMetrics = context.resources.displayMetrics
        val density = displayMetrics.densityDpi

        // Determine which folder to create based on density
        val (folderName, targetSize) = HeaderConfig.DENSITY_CONFIGS
            .entries
            .firstOrNull { density <= it.key }
            ?.value
            ?: HeaderConfig.DENSITY_CONFIGS[Int.MAX_VALUE]!!

        val (targetWidth, targetHeight) = targetSize

        val baseDocDir = DocumentFile.fromTreeUri(context, baseUri) ?: return@withContext null

        val brandingDocDir = baseDocDir.findFile(HeaderConfig.BRANDING_FOLDER_NAME)
            ?: baseDocDir.createDirectory(HeaderConfig.BRANDING_FOLDER_NAME)
            ?: return@withContext null

        // Create .nomedia file to prevent icons from appearing in gallery
        if (brandingDocDir.findFile(".nomedia") == null) {
            brandingDocDir.createFile("application/octet-stream", ".nomedia")
        }

        val headerDocDir = brandingDocDir.findFile(HeaderConfig.headerFolderName(packageName))
            ?: brandingDocDir.createDirectory(HeaderConfig.headerFolderName(packageName))
            ?: return@withContext null

        val drawableDocDir = headerDocDir.findFile(folderName)
            ?: headerDocDir.createDirectory(folderName)
            ?: return@withContext null

        // Save light header (only for apps that support it)
        if (lightHeaderBitmap != null) {
            val lightScaled = createScaledHeader(
                context = context,
                sourceBitmap = lightHeaderBitmap,
                targetWidth = targetWidth,
                targetHeight = targetHeight,
                scale = lightScale,
                offsetX = lightOffsetX,
                offsetY = lightOffsetY
            )
            val lightDocFile = drawableDocDir.findFile("${HeaderConfig.LIGHT_HEADER_FILE_NAME}.png")
                ?: drawableDocDir.createFile("image/png", "${HeaderConfig.LIGHT_HEADER_FILE_NAME}.png")
            lightDocFile?.let {
                context.contentResolver.openOutputStream(it.uri)?.use { out ->
                    lightScaled.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
            lightScaled.recycle()
        }

        // Save dark header
        val darkScaled = createScaledHeader(
            context = context,
            sourceBitmap = darkHeaderBitmap,
            targetWidth = targetWidth,
            targetHeight = targetHeight,
            scale = darkScale,
            offsetX = darkOffsetX,
            offsetY = darkOffsetY
        )
        val darkDocFile = drawableDocDir.findFile("${HeaderConfig.DARK_HEADER_FILE_NAME}.png")
            ?: drawableDocDir.createFile("image/png", "${HeaderConfig.DARK_HEADER_FILE_NAME}.png")
        darkDocFile?.let {
            context.contentResolver.openOutputStream(it.uri)?.use { out ->
                darkScaled.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        }
        darkScaled.recycle()

        headerDocDir.uri.toFilePath()
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

/**
 * Helper function to create scaled and positioned header bitmap.
 * Uses the same logic as preview: fit image to canvas, then apply scale and offset.
 */
@SuppressLint("UseKtx")
private fun createScaledHeader(
    context: Context,
    sourceBitmap: Bitmap,
    targetWidth: Int,
    targetHeight: Int,
    scale: Float,
    offsetX: Float,
    offsetY: Float
): Bitmap {
    // Create output bitmap
    val outputBitmap = createBitmap(targetWidth, targetHeight)
    val canvas = Canvas(outputBitmap)

    // Get density to convert preview canvas offsets to target bitmap offsets
    val density = context.resources.displayMetrics.density

    // Preview canvas size in pixels
    val previewCanvasWidth = targetWidth * density
    val previewCanvasHeight = targetHeight * density

    // Calculate base size by fitting image to canvas (same logic as preview)
    val imageAspect = sourceBitmap.width.toFloat() / sourceBitmap.height.toFloat()
    val canvasAspect = previewCanvasWidth / previewCanvasHeight

    val (baseWidth, baseHeight) = if (imageAspect > canvasAspect) {
        // Image is wider - fit to width
        previewCanvasWidth to (previewCanvasWidth / imageAspect)
    } else {
        // Image is taller - fit to height
        (previewCanvasHeight * imageAspect) to previewCanvasHeight
    }

    // Apply user scale (same as preview)
    val scaledWidth = baseWidth * scale
    val scaledHeight = baseHeight * scale

    // Convert to target bitmap coordinates
    val targetScaledWidth = scaledWidth / density
    val targetScaledHeight = scaledHeight / density

    // Convert offsets from preview canvas pixels to target bitmap pixels
    val targetOffsetX = offsetX / density
    val targetOffsetY = offsetY / density

    // Calculate position (same logic as preview)
    val left = (targetWidth - targetScaledWidth) / 2 + targetOffsetX
    val top = (targetHeight - targetScaledHeight) / 2 + targetOffsetY

    // Create Paint with antialiasing and bicubic filtering for high-quality scaling
    val bitmapPaint = Paint().apply {
        isAntiAlias = true
        isFilterBitmap = true
        isDither = true
    }

    // Draw the scaled and positioned image with antialiasing (will be cropped to canvas bounds)
    val destRect = RectF(left, top, left + targetScaledWidth, top + targetScaledHeight)
    canvas.drawBitmap(sourceBitmap, null, destRect, bitmapPaint)

    return outputBitmap
}
