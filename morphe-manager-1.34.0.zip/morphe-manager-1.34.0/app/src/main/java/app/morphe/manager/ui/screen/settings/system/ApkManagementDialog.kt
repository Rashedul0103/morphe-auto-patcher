/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-manager
 */

package app.morphe.manager.ui.screen.settings.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.net.Uri
import android.view.HapticFeedbackConstants
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.morphe.manager.R
import app.morphe.manager.data.room.apps.installed.InstallType
import app.morphe.manager.data.room.apps.installed.InstalledApp
import app.morphe.manager.data.room.apps.installed.supportsMount
import app.morphe.manager.data.room.apps.original.OriginalApk
import app.morphe.manager.domain.apk.InstalledPatchState
import app.morphe.manager.domain.apk.LocalApkSources
import app.morphe.manager.domain.installer.InstallerFileProvider
import app.morphe.manager.domain.installer.InstallerManager
import app.morphe.manager.domain.installer.UninstallCancelledException
import app.morphe.manager.domain.manager.PreferencesManager
import app.morphe.manager.domain.repository.InstalledAppRepository
import app.morphe.manager.domain.repository.OriginalApkRepository
import app.morphe.manager.patcher.util.NativeLibs
import app.morphe.manager.ui.screen.shared.*
import app.morphe.manager.ui.viewmodel.InstallViewModel
import app.morphe.manager.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.koinInject
import java.io.File
import java.util.Locale

/** Type of APKs to manage. */
enum class ApkManagementType {
    PATCHED,
    ORIGINAL
}

/** Data class representing an APK item for display. */
data class ApkItemData(
    val packageName: String,
    val displayName: String,
    val version: String,
    val fileSize: Long,
    val file: File? = null,
    val installType: InstallType? = null,
    val isInstalledOnDevice: Boolean = false,
    val abis: List<String> = emptyList(),
    /** Info of the APK the row stands for, so its icon comes from that APK without another lookup. */
    val packageInfo: PackageInfo? = null,
    /**
     * Package the sources know the app by, which a patched app renamed on the way no longer
     * carries itself. Its color is looked up by this one, as the home screen does.
     */
    val originalPackageName: String = packageName
)

private val ApkItemData.selectionKey: String
    get() = file?.absolutePath ?: "$packageName:$version"

private val ApkItemData.isInstallableFromStorage: Boolean
    get() = file?.exists() == true && installType != InstallType.MOUNT

private fun List<ApkItemData>.sortedByDisplayName(): List<ApkItemData> =
    sortedBy { it.displayName.lowercase(Locale.ROOT) }

private val ApkItemData.installLabelRes: Int
    get() = when (installType) {
        InstallType.MOUNT -> R.string.mount
        null -> R.string.install
        else -> R.string.reinstall
    }

/** Data class representing an APK item with reference to InstalledApp. */
private data class ApkItemDataWithApp(
    val packageName: String,
    val displayName: String,
    val version: String,
    val fileSize: Long,
    val installedApp: InstalledApp,
    val file: File? = null,
    val installType: InstallType = InstallType.SAVED,
    val isInstalledOnDevice: Boolean = false,
    val abis: List<String> = emptyList(),
    val packageInfo: PackageInfo? = null
) {
    fun toApkItemData() = ApkItemData(
        packageName = packageName,
        displayName = displayName,
        version = version,
        fileSize = fileSize,
        file = file,
        installType = installType,
        isInstalledOnDevice = isInstalledOnDevice,
        abis = abis,
        packageInfo = packageInfo,
        originalPackageName = installedApp.originalPackageName
    )
}

/** Pairs a rendered [ApkItemData] with the underlying [OriginalApk] row. */
private data class OriginalApkEntry(
    val data: ApkItemData,
    val apk: OriginalApk
)

private sealed interface ApkLoadState<out T> {
    data object Loading : ApkLoadState<Nothing>
    data class Loaded<out T>(val items: List<T>) : ApkLoadState<T>
}

/** Static metadata for the APK list header and empty state. */
@Immutable
data class ApkListMeta(
    val title: String,
    val icon: ImageVector,
    val accentColor: Color,
    val count: Int,
    val totalSize: Long,
    val isLoading: Boolean,
    val isEmpty: Boolean,
    val emptyMessage: String,
    val deleteAllTitle: String?,
    val zipExportFileName: String
)

/** Retention preference toggle rendered inside the APK management dialog. */
@Immutable
data class RetentionToggle(
    val title: String,
    val description: String,
    val checked: Boolean,
    val onCheckedChange: (Boolean) -> Unit
)

/** Callbacks for per-item and bulk APK operations. */
@Stable
class ApkListActions(
    val onShare: ((ApkItemData) -> Unit)?,
    val onExport: ((ApkItemData) -> Unit)?,
    val onInstall: ((ApkItemData) -> Unit)?,
    val onInstallSelected: ((List<ApkItemData>) -> Unit)?,
    val onUninstall: ((ApkItemData) -> Unit)?,
    val onUninstallSelected: ((List<ApkItemData>) -> Unit)?,
    val onDelete: (ApkItemData) -> Unit,
    val onDeleteSelectedConfirm: (List<ApkItemData>) -> Unit,
    val onDeleteAllConfirm: (() -> Unit)?
)

/**
 * Universal dialog for managing APK files (patched or original).
 */
@Composable
fun ApkManagementDialog(
    type: ApkManagementType,
    onDismissRequest: () -> Unit
) {
    val installViewModel: InstallViewModel = koinViewModel()
    when (type) {
        ApkManagementType.PATCHED -> PatchedApksContent(onDismissRequest, installViewModel)
        ApkManagementType.ORIGINAL -> OriginalApksContent(onDismissRequest, installViewModel)
    }
    InstallerFlowDialogs(installViewModel = installViewModel)
}

@Composable
private fun PatchedApksContent(
    onDismissRequest: () -> Unit,
    installViewModel: InstallViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val saveApkSuccessText = stringResource(R.string.save_apk_success)
    val patchedApksDeletedText = stringResource(R.string.settings_system_patched_apks_deleted)
    val apksDeletedAllText = stringResource(R.string.settings_system_apks_deleted_all)
    val apksDeleteFailedText = stringResource(R.string.settings_system_apks_delete_failed)
    val repository: InstalledAppRepository = koinInject()
    val originalApkRepository: OriginalApkRepository = koinInject()
    val appDataResolver: AppDataResolver = koinInject()
    val prefs: PreferencesManager = koinInject()
    val pm: PM = koinInject()
    val localApkSources: LocalApkSources = koinInject()
    val installerManager: InstallerManager = koinInject()
    val savePatchedApks by prefs.savePatchedApks.getAsState()

    var state by remember { mutableStateOf<ApkLoadState<ApkItemDataWithApp>>(ApkLoadState.Loading) }

    LaunchedEffect(Unit) {
        combine(
            repository.getAll(),
            repository.savedPatchedApkChanges.onStart { emit(emptySet()) }
        ) { apps, _ -> apps }.collectLatest { apps ->
            state = ApkLoadState.Loaded(
                withContext(Dispatchers.IO) {
                    // Records read once for all rows
                    val records = ResolverRecords(apps, originalApkRepository.getAll().first())
                    apps.mapNotNull { app ->
                        // Only the copies this record owns, so a renamed app never lists the
                        // archive an unrenamed record keeps under the same original name
                        val storedFile = repository.savedPatchedApkFiles(app)
                            .firstOrNull { it.exists() } ?: return@mapNotNull null
                        val snapshot = localApkSources.trackedAppSnapshot(app)
                        val savedFile = snapshot.savedPatchedApk

                        // Use AppDataResolver to get data
                        val resolvedData = appDataResolver.resolveAppData(
                            app.currentPackageName,
                            preferredSource = AppDataSource.PATCHED_APK,
                            records = records
                        )
                        // Taken from the archive the row actually points at, which can differ from
                        // the resolver's answer once the installed app is no longer the patched one
                        val savedDisplayName = snapshot.savedPatchedApkInfo
                            ?.let { packageInfo -> runCatching { with(pm) { packageInfo.label() } }.getOrNull() }
                            ?.takeUnless(String::isBlank)

                        ApkItemDataWithApp(
                            packageName = app.currentPackageName,
                            displayName = savedDisplayName ?: resolvedData.displayName,
                            version = app.version,
                            fileSize = (savedFile ?: storedFile).length(),
                            installedApp = app,
                            file = savedFile,
                            installType = app.installType,
                            isInstalledOnDevice = snapshot.patchState == InstalledPatchState.Patched,
                            abis = savedFile?.let(NativeLibs::extractAbisFromApk).orEmpty(),
                            packageInfo = snapshot.savedPatchedApkInfo ?: resolvedData.packageInfo
                        )
                    }
                }
            )
        }
    }

    val isLoading = state is ApkLoadState.Loading
    val apkItems = (state as? ApkLoadState.Loaded)?.items ?: emptyList()
    val totalSize = remember(state) { apkItems.sumOf { it.fileSize } }
    var pendingDelete by remember { mutableStateOf<Pair<ApkItemData, InstalledApp>?>(null) }

    // Look up by selectionKey to avoid index shifts on concurrent list updates
    val displayItems = remember(state) { apkItems.map { it.toApkItemData() }.sortedByDisplayName() }
    val appByKey = remember(state) {
        apkItems.associate { it.toApkItemData().selectionKey to it.installedApp }
    }

    fun updateInstalledState(packageName: String, installed: Boolean) {
        val loaded = state as? ApkLoadState.Loaded ?: return
        state = ApkLoadState.Loaded(
            loaded.items.map { item ->
                if (item.packageName == packageName || item.installedApp.originalPackageName == packageName) {
                    item.copy(isInstalledOnDevice = installed)
                } else {
                    item
                }
            }
        )
    }

    fun installRequests(items: List<ApkItemData>) = items.mapNotNull { item ->
        val installedApp = appByKey[item.selectionKey] ?: return@mapNotNull null
        val file = item.file?.takeIf { it.exists() } ?: return@mapNotNull null
        InstallQueueRequest(
            file = file,
            originalPackageName = installedApp.originalPackageName,
            mountPackageName = installedApp.currentPackageName.takeIf { installedApp.supportsMount },
            onPersistApp = { packageName, installType ->
                val appliedPatches = repository.getAppliedPatches(installedApp.currentPackageName)
                repository.addOrUpdate(
                    currentPackageName = packageName,
                    originalPackageName = installedApp.originalPackageName,
                    isClone = installedApp.isClone,
                    version = installedApp.version,
                    installType = installType,
                    patchSelection = appliedPatches,
                    selectionPayload = installedApp.selectionPayload,
                    patchedAt = installedApp.patchedAt
                )
                true
            },
            onInstalled = { packageName ->
                updateInstalledState(item.packageName, true)
                updateInstalledState(packageName, true)
            }
        )
    }

    val startInstallQueue = rememberInstallQueue(
        installViewModel = installViewModel,
        completedPluralRes = R.plurals.batch_reinstall_summary
    )

    val uninstallTimeoutText = stringResource(R.string.uninstall_timeout)
    val uninstallFailTemplate = stringResource(R.string.uninstall_app_fail)
    val uninstallUnverifiedText = stringResource(R.string.uninstall_app_unverified)

    fun uninstallItems(items: List<ApkItemData>) {
        if (items.isEmpty()) return
        scope.launch {
            var completed = 0
            var skipped = 0
            var unverified = 0
            for (item in items) {
                val installedApp = appByKey[item.selectionKey]
                val result = runCatching {
                    // Unmounting is safe without verification, every other mode removes a package
                    if (item.installType != InstallType.MOUNT &&
                        (installedApp == null ||
                                localApkSources.trackedPatchState(installedApp) != InstalledPatchState.Patched)
                    ) {
                        unverified++
                        return@runCatching false
                    }
                    val removed = withTimeoutOrNull(BATCH_UNINSTALL_TIMEOUT) {
                        uninstallStorageItem(
                            item = item,
                            installedApp = installedApp,
                            installerManager = installerManager,
                            installedAppRepository = repository
                        )
                        true
                    } == true
                    if (!removed) error(uninstallTimeoutText)
                    true
                }
                result.onSuccess { removed ->
                    if (removed) completed++ else skipped++
                    updateInstalledState(item.packageName, false)
                }.onFailure { error ->
                    skipped++
                    if (error !is UninstallCancelledException) {
                        context.toast(uninstallFailTemplate.format(error.simpleMessage()))
                    }
                }
            }
            if (unverified > 0) context.toast(uninstallUnverifiedText)
            context.batchActionSummary(R.plurals.batch_uninstall_summary, completed, skipped)
                ?.let { context.toast(it) }
        }
    }

    var itemToExport by remember { mutableStateOf<ApkItemData?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(APK_MIMETYPE)
    ) { uri ->
        val item = itemToExport ?: return@rememberLauncherForActivityResult
        itemToExport = null
        uri?.let {
            scope.launch {
                withContext(Dispatchers.IO) {
                    item.file?.let { file ->
                        context.contentResolver.openOutputStream(it)?.use { out ->
                            file.inputStream().use { input -> input.copyTo(out) }
                        }
                    }
                }
                context.toast(saveApkSuccessText)
            }
        }
    }

    ApkManagementDialogContent(
        meta = ApkListMeta(
            title = stringResource(R.string.settings_system_patched_apks_title),
            icon = Icons.Outlined.Apps,
            accentColor = StorageColors.PatchedApks,
            count = displayItems.size,
            totalSize = totalSize,
            isLoading = isLoading,
            isEmpty = displayItems.isEmpty() && !isLoading,
            emptyMessage = stringResource(R.string.settings_system_patched_apks_empty),
            deleteAllTitle = stringResource(R.string.settings_system_patched_apks_delete_all_title),
            zipExportFileName = stringResource(R.string.settings_system_patched_apks_export_zip_name)
        ),
        retentionToggle = RetentionToggle(
            title = stringResource(R.string.settings_system_save_patched_apks_title),
            description = stringResource(R.string.settings_system_save_patched_apks_description),
            checked = savePatchedApks,
            onCheckedChange = { checked -> scope.launch { prefs.savePatchedApks.update(checked) } }
        ),
        actions = ApkListActions(
            onShare = { item ->
                item.file?.let { file ->
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) {
                            InstallerFileProvider.getUriForFile(context, file)
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = APK_MIMETYPE
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        try {
                            context.startActivity(Intent.createChooser(intent, null))
                        } catch (_: android.content.ActivityNotFoundException) { }
                    }
                }
            },
            onExport = { item ->
                itemToExport = item
                exportLauncher.launch("${item.displayName.replace(" ", "_")}.apk")
            },
            onInstall = { item ->
                if (item.installType == InstallType.MOUNT) {
                    installViewModel.mount(
                        packageName = item.packageName,
                        version = item.version
                    )
                } else {
                    startInstallQueue(installRequests(listOf(item)))
                }
            },
            onInstallSelected = { selectedItems -> startInstallQueue(installRequests(selectedItems)) },
            onUninstall = { item -> uninstallItems(listOf(item)) },
            onUninstallSelected = { selectedItems -> uninstallItems(selectedItems) },
            onDelete = { item ->
                appByKey[item.selectionKey]?.let { pendingDelete = item to it }
            },
            onDeleteSelectedConfirm = { selectedItems ->
                val appsToDelete = selectedItems.mapNotNull { appByKey[it.selectionKey] }
                scope.launch {
                    val deleted = repository.deleteSavedPatchedApks(appsToDelete)
                    context.toast(if (deleted) apksDeletedAllText else apksDeleteFailedText)
                }
            },
            onDeleteAllConfirm = {
                val appsToDelete = apkItems.map { it.installedApp }
                scope.launch {
                    val deleted = repository.deleteSavedPatchedApks(appsToDelete)
                    context.toast(if (deleted) apksDeletedAllText else apksDeleteFailedText)
                }
            }
        ),
        items = displayItems,
        onDismissRequest = onDismissRequest
    )

    pendingDelete?.let { (data, app) ->
        ApkDeleteConfirmDialog(
            data = data,
            title = stringResource(R.string.settings_system_patched_apks_delete_title),
            fileIcon = Icons.Outlined.Android,
            fileLabel = stringResource(R.string.home_app_info_delete_item_patched_apk),
            onDismiss = { pendingDelete = null },
            onConfirm = {
                scope.launch {
                    val deleted = repository.deleteSavedPatchedApk(app)
                    context.toast(if (deleted) patchedApksDeletedText else apksDeleteFailedText)
                    pendingDelete = null
                }
            }
        )
    }
}

@Composable
private fun OriginalApksContent(
    onDismissRequest: () -> Unit,
    installViewModel: InstallViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val saveApkSuccessText = stringResource(R.string.save_apk_success)
    val originalApksDeletedText = stringResource(R.string.settings_system_original_apks_deleted)
    val apksDeletedAllText = stringResource(R.string.settings_system_apks_deleted_all)
    val repository: OriginalApkRepository = koinInject()
    val installedAppRepository: InstalledAppRepository = koinInject()
    val appDataResolver: AppDataResolver = koinInject()
    val prefs: PreferencesManager = koinInject()
    val pm: PM = koinInject()
    val installerManager: InstallerManager = koinInject()
    val saveOriginalApks by prefs.saveOriginalApks.getAsState()

    var state by remember { mutableStateOf<ApkLoadState<OriginalApkEntry>>(ApkLoadState.Loading) }

    LaunchedEffect(Unit) {
        // Records left behind by a file that is already gone would show a stale size and count
        repository.pruneMissingApks()
        repository.getAll().collect { apks ->
            state = ApkLoadState.Loaded(
                withContext(Dispatchers.IO) {
                    // Records read once for all rows
                    val records = ResolverRecords(installedAppRepository.getAll().first(), apks)
                    apks.map { apk ->
                        val resolvedData = appDataResolver.resolveAppData(
                            apk.packageName,
                            preferredSource = AppDataSource.ORIGINAL_APK,
                            records = records
                        )
                        val apkFile = File(apk.filePath).takeIf { it.exists() }

                        OriginalApkEntry(
                            data = ApkItemData(
                                packageName = apk.packageName,
                                displayName = resolvedData.displayName,
                                version = apk.version,
                                fileSize = apk.fileSize,
                                file = apkFile,
                                isInstalledOnDevice = pm.getPackageInfo(apk.packageName) != null,
                                abis = apkFile?.let(NativeLibs::extractAbisFromApk).orEmpty(),
                                packageInfo = resolvedData.packageInfo
                            ),
                            apk = apk
                        )
                    }
                }
            )
        }
    }

    val isLoading = state is ApkLoadState.Loading
    val entries = (state as? ApkLoadState.Loaded)?.items ?: emptyList()
    val apkItems = remember(state) { entries.map { it.data }.sortedByDisplayName() }
    val apkByKey = remember(state) { entries.associate { it.data.selectionKey to it.apk } }
    val totalSize = remember(state) { apkItems.sumOf { it.fileSize } }
    var pendingDelete by remember { mutableStateOf<Pair<ApkItemData, OriginalApk>?>(null) }

    fun updateInstalledState(packageName: String, installed: Boolean) {
        val loaded = state as? ApkLoadState.Loaded ?: return
        state = ApkLoadState.Loaded(
            loaded.items.map { entry ->
                if (entry.data.packageName == packageName) {
                    entry.copy(data = entry.data.copy(isInstalledOnDevice = installed))
                } else {
                    entry
                }
            }
        )
    }

    fun installRequests(items: List<ApkItemData>) = items.mapNotNull { item ->
        val file = item.file?.takeIf { it.exists() } ?: return@mapNotNull null
        InstallQueueRequest(
            file = file,
            originalPackageName = item.packageName,
            onPersistApp = { _, _ -> true },
            onInstalled = { packageName ->
                updateInstalledState(item.packageName, true)
                updateInstalledState(packageName, true)
            }
        )
    }

    val startInstallQueue = rememberInstallQueue(
        installViewModel = installViewModel,
        completedPluralRes = R.plurals.batch_install_summary
    )

    val uninstallTimeoutText = stringResource(R.string.uninstall_timeout)
    val uninstallFailTemplate = stringResource(R.string.uninstall_app_fail)

    fun uninstallItems(items: List<ApkItemData>) {
        if (items.isEmpty()) return
        scope.launch {
            var completed = 0
            var skipped = 0
            for (item in items) {
                val result = runCatching {
                    val removed = withTimeoutOrNull(BATCH_UNINSTALL_TIMEOUT) {
                        uninstallStorageItem(
                            item = item,
                            installedApp = null,
                            installerManager = installerManager,
                            installedAppRepository = null
                        )
                        true
                    } == true
                    if (!removed) error(uninstallTimeoutText)
                }
                result.onSuccess {
                    completed++
                    updateInstalledState(item.packageName, false)
                }.onFailure { error ->
                    skipped++
                    if (error !is UninstallCancelledException) {
                        context.toast(uninstallFailTemplate.format(error.simpleMessage()))
                    }
                }
            }
            context.batchActionSummary(R.plurals.batch_uninstall_summary, completed, skipped)
                ?.let { context.toast(it) }
        }
    }

    var itemToExport by remember { mutableStateOf<ApkItemData?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(APK_MIMETYPE)
    ) { uri ->
        val item = itemToExport ?: return@rememberLauncherForActivityResult
        itemToExport = null
        uri?.let {
            scope.launch {
                withContext(Dispatchers.IO) {
                    item.file?.let { file ->
                        context.contentResolver.openOutputStream(it)?.use { out ->
                            file.inputStream().use { input -> input.copyTo(out) }
                        }
                    }
                }
                context.toast(saveApkSuccessText)
            }
        }
    }

    ApkManagementDialogContent(
        meta = ApkListMeta(
            title = stringResource(R.string.settings_system_original_apks_title),
            icon = Icons.Outlined.Storage,
            accentColor = StorageColors.OriginalApks,
            count = apkItems.size,
            totalSize = totalSize,
            isLoading = isLoading,
            isEmpty = apkItems.isEmpty() && !isLoading,
            emptyMessage = stringResource(R.string.settings_system_original_apks_empty),
            deleteAllTitle = stringResource(R.string.settings_system_original_apks_delete_all_title),
            zipExportFileName = stringResource(R.string.settings_system_original_apks_export_zip_name)
        ),
        retentionToggle = RetentionToggle(
            title = stringResource(R.string.settings_system_save_original_apks_title),
            description = stringResource(R.string.settings_system_save_original_apks_description),
            checked = saveOriginalApks,
            onCheckedChange = { checked -> scope.launch { prefs.saveOriginalApks.update(checked) } }
        ),
        actions = ApkListActions(
            onShare = { item ->
                item.file?.let { file ->
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) {
                            InstallerFileProvider.getUriForFile(context, file)
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = APK_MIMETYPE
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        try {
                            context.startActivity(Intent.createChooser(intent, null))
                        } catch (_: android.content.ActivityNotFoundException) { }
                    }
                }
            },
            onExport = { item ->
                itemToExport = item
                exportLauncher.launch("${item.displayName.replace(" ", "_")}.apk")
            },
            onInstall = { item -> startInstallQueue(installRequests(listOf(item))) },
            onInstallSelected = { selectedItems -> startInstallQueue(installRequests(selectedItems)) },
            onUninstall = { item -> uninstallItems(listOf(item)) },
            onUninstallSelected = { selectedItems -> uninstallItems(selectedItems) },
            onDelete = { item ->
                apkByKey[item.selectionKey]?.let { pendingDelete = item to it }
            },
            onDeleteSelectedConfirm = { selectedItems ->
                val apksToDelete = selectedItems.mapNotNull { apkByKey[it.selectionKey] }
                scope.launch {
                    apksToDelete.forEach { repository.delete(it) }
                    context.toast(apksDeletedAllText)
                }
            },
            onDeleteAllConfirm = {
                val apksToDelete = entries.map { it.apk }
                scope.launch {
                    apksToDelete.forEach { repository.delete(it) }
                    context.toast(apksDeletedAllText)
                }
            }
        ),
        items = apkItems,
        onDismissRequest = onDismissRequest
    )

    pendingDelete?.let { (data, apk) ->
        ApkDeleteConfirmDialog(
            data = data,
            title = stringResource(R.string.settings_system_original_apks_delete_title),
            fileIcon = Icons.Outlined.FilePresent,
            fileLabel = stringResource(R.string.home_app_info_delete_item_original_apk),
            notice = stringResource(R.string.settings_system_original_apks_delete_notice),
            onDismiss = { pendingDelete = null },
            onConfirm = {
                scope.launch {
                    repository.delete(apk)
                    context.toast(originalApksDeletedText)
                    pendingDelete = null
                }
            }
        )
    }
}

@Composable
private fun ApkManagementDialogContent(
    meta: ApkListMeta,
    actions: ApkListActions,
    items: List<ApkItemData>,
    onDismissRequest: () -> Unit,
    retentionToggle: RetentionToggle? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showDeleteAllConfirmation by remember { mutableStateOf(false) }
    var showDeleteSelectedConfirmation by remember { mutableStateOf(false) }
    var showUninstallSelectedConfirmation by remember { mutableStateOf(false) }
    var itemToUninstallConfirm by remember { mutableStateOf<ApkItemData?>(null) }
    var isMultiSelectMode by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    val selection = rememberSelectionState<String>()
    // Nothing to narrow down while loading or with a single entry
    val isSearchable = !meta.isLoading && items.size >= 2
    val search = rememberSearchFieldState(searchable = isSearchable)
    val filteredItems = remember(items, search.query) {
        if (search.query.isBlank()) items
        else items.filter {
            it.displayName.contains(search.query, ignoreCase = true) ||
                    it.packageName.contains(search.query, ignoreCase = true)
        }
    }
    val selectedItems = items.filter { selection.contains(it.selectionKey) }
    val selectedFiles = selectedItems.mapNotNull { item -> item.file?.takeIf { it.exists() } }
    val selectedInstalledItems = selectedItems.filter { it.isInstalledOnDevice }
    val selectedInstallableItems = selectedItems.filter {
        !it.isInstalledOnDevice && it.isInstallableFromStorage
    }
    val canUninstallSelected = selectedItems.isNotEmpty() &&
            selectedInstalledItems.size == selectedItems.size &&
            actions.onUninstallSelected != null
    val canInstallSelected = selectedItems.isNotEmpty() &&
            selectedInstallableItems.size == selectedItems.size &&
            actions.onInstallSelected != null
    val canDeleteAll = selectedItems.isEmpty() && items.isNotEmpty() &&
            actions.onDeleteAllConfirm != null
    val selectedTotalSize = selectedItems.sumOf { it.fileSize }
    val zipExportSuccessText = stringResource(R.string.settings_system_apks_export_zip_success)
    val zipExportFailedText = stringResource(R.string.settings_system_apks_export_zip_failed)
    var zipExportItems by remember { mutableStateOf<List<ApkItemData>>(emptyList()) }

    LaunchedEffect(items) {
        val currentKeys = items.map { it.selectionKey }.toSet()
        selection.retain { it in currentKeys }
    }

    val zipExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val itemsToExport = zipExportItems
        zipExportItems = emptyList()
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            isExporting = true
            try {
                val exported = withContext(Dispatchers.IO) {
                    ZipUtils.zip(context, uri, itemsToExport.mapNotNull { it.file })
                }
                context.toast(if (exported) zipExportSuccessText else zipExportFailedText)
                if (exported) selection.clear()
            } finally {
                isExporting = false
            }
        }
    }

    AppDialog(
        onDismissRequest = {
            if (!isExporting) onDismissRequest()
        },
        accentColor = meta.accentColor,
        footer = {
            AppDialogOutlinedButton(
                text = stringResource(R.string.close),
                onClick = onDismissRequest,
                modifier = Modifier.fillMaxWidth()
            )
        },
        bottomBar = if (isMultiSelectMode) {
            {
                MultiSelectShell(
                    visible = true,
                    onBack = { selection.clear(); isMultiSelectMode = false }
                ) {
                    val installLabel = stringResource(
                        selectedInstallableItems
                            .map { it.installLabelRes }
                            .distinct()
                            .singleOrNull() ?: R.string.install
                    )
                    val shareLabel = stringResource(R.string.share)
                    val exportLabel = stringResource(R.string.export)
                    val uninstallLabel = stringResource(R.string.uninstall)
                    val deleteLabel = stringResource(R.string.delete)
                    SelectionActionBar(
                        selectedCount = selectedItems.size,
                        // Scoped to the filtered list so "select all" never reaches hidden entries
                        totalCount = filteredItems.size,
                        subtitle = stringResource(
                            R.string.settings_system_apks_size,
                            context.formatBytes(selectedTotalSize)
                        ),
                        onSelectAll = { selection.setAll(filteredItems.map { it.selectionKey }) },
                        onDeselectAll = { selection.clear() },
                        onCancel = { selection.clear(); isMultiSelectMode = false },
                        actions = buildList {
                            if (canInstallSelected) {
                                add(
                                    SelectionAction(
                                        icon = Icons.Outlined.InstallMobile,
                                        label = installLabel,
                                        onClick = {
                                            actions.onInstallSelected.invoke(selectedInstallableItems)
                                            selection.clear()
                                        },
                                        tone = ActionTone.Primary
                                    )
                                )
                            }

                            if (selectedFiles.isNotEmpty()) {
                                add(
                                    SelectionAction(
                                        icon = Icons.Outlined.Share,
                                        label = shareLabel,
                                        onClick = {
                                            scope.launch {
                                                shareApkFiles(context, selectedFiles)
                                            }
                                        }
                                    )
                                )
                                add(
                                    SelectionAction(
                                        icon = Icons.Outlined.Upload,
                                        label = exportLabel,
                                        onClick = {
                                            zipExportItems = selectedItems
                                            zipExportLauncher.launch(FilenameUtils.timestamped(meta.zipExportFileName))
                                        }
                                    )
                                )
                            }

                            if (canUninstallSelected) {
                                add(
                                    SelectionAction(
                                        icon = Icons.Outlined.DeleteForever,
                                        label = uninstallLabel,
                                        onClick = { showUninstallSelectedConfirmation = true },
                                        tone = ActionTone.Destructive
                                    )
                                )
                            }

                            add(
                                SelectionAction(
                                    icon = Icons.Outlined.Delete,
                                    label = deleteLabel,
                                    onClick = { showDeleteSelectedConfirmation = true },
                                    tone = ActionTone.Destructive
                                )
                            )
                        }
                    )
                }
            }
        } else null,
        scrollable = false,
        padding = DialogPadding.Compact,
        contentArrangement = Arrangement.Top,
        fillContentHeight = true,
        hideFooterWhileTyping = true
    ) {
        SearchFieldBackHandler(search)

        ListDialogHeader(
            icon = { modifier ->
                ListDialogHeaderIcon(icon = meta.icon, color = meta.accentColor, modifier = modifier)
            },
            title = meta.title,
            subtitle = listOf(
                pluralStringResource(R.plurals.settings_system_apks_count, meta.count, meta.count.toString()),
                // The bare size: the count before it already says what it is the size of
                context.formatBytes(meta.totalSize)
            ).joinToString(" · "),
            // Sums the list up once the files are counted
            subtitleLoading = meta.isLoading,
            search = search,
            searchLabel = stringResource(R.string.search),
            searchEnabled = isSearchable
        ) {
            TitleAction(
                icon = Icons.Outlined.DeleteForever,
                contentDescription = stringResource(R.string.delete_all),
                onClick = { showDeleteAllConfirmation = true },
                style = TitleActionStyle.Destructive,
                enabled = canDeleteAll
            )
        }

        DialogLazyList(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(Defaults.ItemSpacing),
            pinnedFirstRow = true
        ) {
            // Kept while the field is closed, so its share of the spacing makes the gap under
            // the header
            stickyHeader(key = "search") {
                AppDialogSearchHeader(
                    visible = search.visible,
                    value = search.query,
                    onValueChange = { search.query = it },
                    label = stringResource(R.string.home_search_apps),
                    // Opaque, so rows scrolled under the gap stay hidden
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.background)
                        .padding(top = Defaults.ItemSpacing)
                )
            }

            if (retentionToggle != null) {
                item(key = "retention") {
                    Column(verticalArrangement = Arrangement.spacedBy(Defaults.ItemSpacing)) {
                        SettingsSwitchItem(
                            checked = retentionToggle.checked,
                            onToggle = { retentionToggle.onCheckedChange(!retentionToggle.checked) },
                            leadingContent = { ThemedIcon(icon = meta.icon, tint = meta.accentColor) },
                            title = retentionToggle.title,
                            subtitle = retentionToggle.description,
                            showBorder = true
                        )
                        SettingsDivider(fullWidth = true)
                    }
                }
            }

            // List of APKs or loading state
            when {
                // Show shimmer while loading
                meta.isLoading -> items(3) { ShimmerApkItem() }
                meta.isEmpty -> item { EmptyState(message = meta.emptyMessage) }
                filteredItems.isEmpty() -> item(key = "search_empty") {
                    EmptyState(
                        message = stringResource(R.string.search_no_results),
                        icon = Icons.Outlined.SearchOff
                    )
                }
                else -> items(items = filteredItems, key = { it.selectionKey }) { item ->
                    val selected = selection.contains(item.selectionKey)
                    ApkItemCard(
                        data = item,
                        selected = selected,
                        selectionMode = isMultiSelectMode,
                        onToggleSelection = { isMultiSelectMode = true; selection.toggle(item.selectionKey) },
                        onShare = if (item.file != null) { { actions.onShare?.invoke(item) } } else null,
                        onExport = if (item.file != null) { { actions.onExport?.invoke(item) } } else null,
                        onInstall = if (!item.isInstalledOnDevice && item.file != null && actions.onInstall != null) {
                            { actions.onInstall.invoke(item) }
                        } else null,
                        onUninstall = if (item.isInstalledOnDevice && actions.onUninstall != null) {
                            { itemToUninstallConfirm = item }
                        } else null,
                        onDelete = { actions.onDelete(item) }
                    )
                }
            }
        }
    }

    Overlay(visible = isExporting) {
        PulsingLogoWithCaption(caption = stringResource(R.string.exporting_apks))
    }

    if (showDeleteAllConfirmation && meta.deleteAllTitle != null && actions.onDeleteAllConfirm != null) {
        ConfirmDialog(
            title = meta.deleteAllTitle,
            message = stringResource(R.string.settings_system_apks_delete_all_confirm),
            primaryText = stringResource(R.string.delete_all),
            items = listOf(apkCountItem(meta.count, meta.totalSize)),
            onDismiss = { showDeleteAllConfirmation = false },
            onConfirm = {
                actions.onDeleteAllConfirm.invoke()
                showDeleteAllConfirmation = false
            }
        )
    }

    if (showDeleteSelectedConfirmation) {
        ConfirmDialog(
            title = stringResource(R.string.settings_system_apks_delete_selected_title),
            message = stringResource(R.string.settings_system_apks_delete_selected_confirm),
            primaryText = stringResource(R.string.delete),
            items = listOf(apkCountItem(selectedItems.size, selectedTotalSize)),
            onDismiss = { showDeleteSelectedConfirmation = false },
            onConfirm = {
                actions.onDeleteSelectedConfirm(selectedItems)
                selection.clear()
                isMultiSelectMode = false
                showDeleteSelectedConfirmation = false
            }
        )
    }

    if (showUninstallSelectedConfirmation) {
        ConfirmDialog(
            title = pluralStringResource(R.plurals.batch_uninstall_confirm_title, selectedInstalledItems.size, selectedInstalledItems.size.toString()),
            message = stringResource(R.string.batch_uninstall_confirm_body),
            primaryText = stringResource(R.string.uninstall),
            onConfirm = {
                actions.onUninstallSelected?.invoke(selectedInstalledItems)
                selection.clear()
                isMultiSelectMode = false
                showUninstallSelectedConfirmation = false
            },
            onDismiss = { showUninstallSelectedConfirmation = false }
        )
    }

    itemToUninstallConfirm?.let { item ->
        ConfirmDialog(
            title = pluralStringResource(R.plurals.batch_uninstall_confirm_title, 1, "1"),
            message = stringResource(R.string.batch_uninstall_confirm_body),
            primaryText = stringResource(R.string.uninstall),
            subject = { ApkConfirmSubject(item) },
            accentColor = rememberAppColor(item.originalPackageName),
            onConfirm = {
                actions.onUninstall?.invoke(item)
                itemToUninstallConfirm = null
            },
            onDismiss = { itemToUninstallConfirm = null }
        )
    }
}

@Composable
private fun ApkItemCard(
    data: ApkItemData,
    selected: Boolean,
    selectionMode: Boolean,
    onToggleSelection: () -> Unit,
    onShare: (() -> Unit)?,
    onExport: (() -> Unit)?,
    onInstall: (() -> Unit)?,
    onUninstall: (() -> Unit)?,
    onDelete: () -> Unit
) {
    val view = LocalView.current

    SelectableCard(
        modifier = Modifier.fillMaxWidth(),
        isSelected = selected,
        isSelectionMode = selectionMode,
        checkmarkContentDescription = stringResource(R.string.selected)
    ) {
        // Worn the way the home screen wears it, so the app reads as itself here too
        SectionCard(accentColor = rememberAppColor(data.originalPackageName)) {
            Column {
                // Header with app icon
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (selectionMode) onToggleSelection()
                            },
                            onLongClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                onToggleSelection()
                            }
                        )
                        .padding(Defaults.ContentPadding),
                    horizontalArrangement = Arrangement.spacedBy(Defaults.ItemSpacing),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // App icon
                    AppIcon(
                        packageInfo = data.packageInfo,
                        packageName = data.packageName,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp)
                    )

                    // App info
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = data.displayName,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium,
                            color = LocalDialogTextColor.current
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = data.packageName,
                                style = MaterialTheme.typography.bodySmall,
                                color = LocalDialogSecondaryTextColor.current
                            )
                            Text(
                                text = stringResource(
                                    R.string.settings_system_apk_item_info,
                                    data.version,
                                    LocalContext.current.formatBytes(data.fileSize)
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = LocalDialogSecondaryTextColor.current
                            )
                            if (data.abis.isNotEmpty()) {
                                Text(
                                    text = data.abis.joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LocalDialogSecondaryTextColor.current
                                )
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = !selectionMode,
                    enter = Animations.expandFadeEnter,
                    exit = Animations.shrinkFadeExit
                ) {
                    Column {
                        SettingsDivider()

                        // Action buttons
                        ActionPillRow(
                            modifier = Modifier.padding(
                                horizontal = Defaults.ContentPadding,
                                vertical = Defaults.ItemSpacing
                            )
                        ) {
                            if (onShare != null) {
                                val shareLabel = stringResource(R.string.share)
                                ActionPillButton(
                                    onClick = onShare,
                                    icon = Icons.Outlined.Share,
                                    contentDescription = shareLabel,
                                    tooltip = shareLabel
                                )
                            }

                            if (onExport != null) {
                                val exportLabel = stringResource(R.string.export)
                                ActionPillButton(
                                    onClick = onExport,
                                    icon = Icons.Outlined.Upload,
                                    contentDescription = exportLabel,
                                    tooltip = exportLabel
                                )
                            }

                            if (onUninstall != null) {
                                val uninstallLabel = stringResource(R.string.uninstall)
                                ActionPillButton(
                                    onClick = onUninstall,
                                    icon = Icons.Outlined.DeleteForever,
                                    contentDescription = uninstallLabel,
                                    tooltip = uninstallLabel,
                                    destructive = true
                                )
                            } else if (onInstall != null) {
                                val isMountType = data.installType == InstallType.MOUNT
                                val installLabel = stringResource(data.installLabelRes)
                                ActionPillButton(
                                    onClick = onInstall,
                                    icon = if (isMountType) Icons.Outlined.Link else Icons.Outlined.InstallMobile,
                                    contentDescription = installLabel,
                                    tooltip = installLabel
                                )
                            }

                            val deleteLabel = stringResource(R.string.delete)
                            ActionPillButton(
                                onClick = onDelete,
                                icon = Icons.Outlined.Delete,
                                contentDescription = deleteLabel,
                                tooltip = deleteLabel,
                                destructive = true
                            )
                        }
                    }
                }
            }
        }
    }
}

private suspend fun uninstallStorageItem(
    item: ApkItemData,
    installedApp: InstalledApp?,
    installerManager: InstallerManager,
    installedAppRepository: InstalledAppRepository?
) {
    installerManager.uninstallPackage(item.packageName, item.installType)
    if (item.installType == InstallType.MOUNT && installedApp != null) {
        installedAppRepository?.delete(installedApp)
    }
}

/** Confirms deleting the one APK of [data], naming its app and the file with its size. */
@Composable
private fun ApkDeleteConfirmDialog(
    data: ApkItemData,
    title: String,
    fileIcon: ImageVector,
    fileLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    notice: String? = null
) {
    ConfirmDialog(
        title = title,
        primaryText = stringResource(R.string.delete),
        onConfirm = onConfirm,
        onDismiss = onDismiss,
        subject = { ApkConfirmSubject(data) },
        accentColor = rememberAppColor(data.originalPackageName),
        items = listOf(ConfirmItem(fileIcon, fileLabel, LocalContext.current.formatBytes(data.fileSize))),
        itemsTitle = stringResource(R.string.home_app_info_remove_app_warning),
        notice = notice
    )
}

/** Head of a confirmation about one APK: the app's icon over its name. */
@Composable
private fun ApkConfirmSubject(data: ApkItemData) {
    ConfirmSubject(name = data.displayName) { modifier ->
        AppIcon(
            packageInfo = data.packageInfo,
            packageName = data.packageName,
            contentDescription = null,
            modifier = modifier
        )
    }
}

/** How many APKs an action removes and how much room that frees, as the one line of its confirmation. */
@Composable
private fun apkCountItem(count: Int, totalSize: Long) = ConfirmItem(
    icon = Icons.Outlined.Delete,
    text = pluralStringResource(R.plurals.settings_system_apks_count, count, count.toString()),
    detail = LocalContext.current.formatBytes(totalSize)
)

private suspend fun shareApkFiles(context: Context, files: List<File>) {
    val existingFiles = files.filter { it.exists() }
    if (existingFiles.isEmpty()) return

    val uris = withContext(Dispatchers.IO) {
        existingFiles.map { InstallerFileProvider.getUriForFile(context, it) }
    }

    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = APK_MIMETYPE
            putExtra(Intent.EXTRA_STREAM, uris.first())
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = APK_MIMETYPE
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(uris))
        }
    }.apply {
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    try {
        context.startActivity(Intent.createChooser(intent, null))
    } catch (_: android.content.ActivityNotFoundException) { }
}
