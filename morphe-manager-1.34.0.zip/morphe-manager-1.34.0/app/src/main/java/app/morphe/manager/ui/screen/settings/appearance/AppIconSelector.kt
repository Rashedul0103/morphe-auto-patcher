/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-manager
 */

package app.morphe.manager.ui.screen.settings.appearance

import androidx.appcompat.content.res.AppCompatResources
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.morphe.manager.R
import app.morphe.manager.domain.manager.AppIconManager
import app.morphe.manager.ui.screen.shared.*
import app.morphe.manager.util.htmlAnnotatedString
import kotlinx.coroutines.launch

/**
 * Settings row showing the launcher icon in use, opening a picker of the others on tap. A pick
 * is confirmed before the launcher icon is swapped.
 */
@Composable
fun AppIconSettingsItem() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val iconManager = remember { AppIconManager(context) }

    val currentIcon = remember { mutableStateOf(iconManager.getCurrentIcon()) }
    val showPicker = remember { mutableStateOf(false) }
    val showConfirmDialog = remember { mutableStateOf<AppIconManager.AppIcon?>(null) }

    SettingsItem(
        onClick = { showPicker.value = true },
        title = stringResource(R.string.settings_appearance_app_icon_selector_title),
        subtitle = stringResource(currentIcon.value.displayNameResId),
        leadingContent = { AppIconPreview(icon = currentIcon.value, size = Defaults.IconSize) }
    )

    if (showPicker.value) {
        AppDialog(
            onDismissRequest = { showPicker.value = false },
            title = stringResource(R.string.settings_appearance_app_icon_selector_title),
            description = stringResource(R.string.settings_appearance_app_icon_selector_description),
            footer = {
                AppDialogOutlinedButton(
                    text = stringResource(R.string.close),
                    onClick = { showPicker.value = false },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        ) {
            OptionGrid(items = AppIconManager.AppIcon.entries, columns = 3) { icon, itemModifier ->
                AppIconCard(
                    icon = icon,
                    isSelected = currentIcon.value == icon,
                    onClick = {
                        if (currentIcon.value != icon) showConfirmDialog.value = icon
                    },
                    modifier = itemModifier
                )
            }
        }
    }

    // Confirmation dialog
    showConfirmDialog.value?.let { selectedIcon ->
        AppIconChangeDialog(
            icon = selectedIcon,
            onConfirm = {
                scope.launch {
                    iconManager.setIcon(selectedIcon)
                    currentIcon.value = selectedIcon
                }
                showConfirmDialog.value = null
                showPicker.value = false
            },
            onDismiss = { showConfirmDialog.value = null }
        )
    }
}

/** A launcher icon drawn at [size] with the rounding the picker gives it. */
@Composable
private fun AppIconPreview(icon: AppIconManager.AppIcon, size: Dp) {
    val context = LocalContext.current
    val iconPainter = rememberDrawablePainter(
        drawable = remember(icon) { AppCompatResources.getDrawable(context, icon.previewIconResId) }
    )
    Image(
        painter = iconPainter,
        contentDescription = null,
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.2f))
    )
}

/**
 * Single app icon card.
 */
@Composable
private fun AppIconCard(
    icon: AppIconManager.AppIcon,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val windowSize = rememberWindowSize()
    val iconSize = when (windowSize.widthSizeClass) {
        WindowWidthSizeClass.Compact -> 48.dp
        WindowWidthSizeClass.Medium -> 52.dp
        WindowWidthSizeClass.Expanded -> 56.dp
    }

    // Increase height in landscape for better text display
    val cardHeight = if (isLandscape()) 108.dp else 96.dp

    SelectionTile(
        selected = isSelected,
        onClick = onClick,
        stateDescription = stringResource(
            if (isSelected) R.string.selected else R.string.not_selected
        ),
        modifier = modifier.heightIn(min = cardHeight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(Defaults.ItemSpacing),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AppIconPreview(icon = icon, size = iconSize)

            Spacer(modifier = Modifier.height(6.dp))

            // Icon name
            Text(
                text = stringResource(icon.displayNameResId),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isSelected) {
                    LocalContentColor.current
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                textAlign = TextAlign.Center,
                maxLines = 2, // Allow 2 lines for longer names
                overflow = TextOverflow.Ellipsis,
                lineHeight = MaterialTheme.typography.bodySmall.fontSize * 1.2
            )
        }
    }
}

/**
 * Confirmation dialog for icon change.
 */
@Composable
private fun AppIconChangeDialog(
    icon: AppIconManager.AppIcon,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AppDialog(
        onDismissRequest = onDismiss,
        title = stringResource(R.string.settings_appearance_app_icon_change_dialog_title),
        description = htmlAnnotatedString(stringResource(
            R.string.settings_appearance_app_icon_change_dialog_message,
            stringResource(icon.displayNameResId)
        )),
        footer = {
            AppDialogButtonRow(
                primaryText = stringResource(R.string.settings_appearance_app_icon_change_dialog_confirm),
                onPrimaryClick = onConfirm,
                secondaryText = stringResource(android.R.string.cancel),
                onSecondaryClick = onDismiss
            )
        }
    )
}
