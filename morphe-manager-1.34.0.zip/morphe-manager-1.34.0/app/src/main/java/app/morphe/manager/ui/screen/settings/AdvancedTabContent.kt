/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-manager
 */

package app.morphe.manager.ui.screen.settings

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.stringResource
import app.morphe.manager.R
import app.morphe.manager.ui.screen.settings.advanced.GitHubPatSettingsItem
import app.morphe.manager.ui.screen.settings.advanced.PatchOptionsSection
import app.morphe.manager.ui.screen.settings.advanced.PatcherTuningSection
import app.morphe.manager.ui.screen.settings.advanced.UpdatesSettingsItem
import app.morphe.manager.ui.screen.shared.*
import app.morphe.manager.ui.viewmodel.HomeViewModel
import app.morphe.manager.ui.viewmodel.PatchOptionsViewModel
import app.morphe.manager.ui.viewmodel.SettingsViewModel
import kotlin.math.roundToInt

/**
 * Advanced tab content.
 */
@Composable
fun AdvancedTabContent(
    patchOptionsViewModel: PatchOptionsViewModel,
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    scrollState: ScrollState = rememberScrollState(),
    onExpertModeItemPositioned: ((Rect) -> Unit)? = null,
    onExpertModeScrollTarget: ((Int) -> Unit)? = null,
    onProcessRuntimePositioned: ((Rect) -> Unit)? = null,
    onProcessRuntimeScrollTarget: ((Int) -> Unit)? = null
) {
    val prefs = settingsViewModel.prefs
    val useExpertMode by prefs.useExpertMode.getAsState()

    // Notify VM on expert mode changes so it can derive showExpertModeNotice
    LaunchedEffect(useExpertMode) {
        settingsViewModel.onExpertModeChanged(useExpertMode)
    }

    val showExpertModeNotice = settingsViewModel.showExpertModeNotice
    val showExpertModeDialog = remember { mutableStateOf(false) }
    val gitHubPat by prefs.gitHubPat.getAsState()
    val includeGitHubPatInExports by prefs.includeGitHubPatInExports.getAsState()

    // Expert mode confirmation dialog
    if (showExpertModeDialog.value) {
        ExpertModeConfirmationDialog(
            onDismiss = { showExpertModeDialog.value = false },
            onConfirm = {
                settingsViewModel.setExpertMode(true)
                showExpertModeDialog.value = false
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScrollFade(scrollState)
            .verticalScroll(scrollState)
            .animateContentSize()
            .padding(settingsTabPadding()),
        verticalArrangement = Arrangement.spacedBy(Defaults.ContentPadding)
    ) {
        // Updates section
        SectionTitle(
            text = stringResource(R.string.settings_advanced_updates),
            icon = Icons.Outlined.Update
        )

        UpdatesSettingsItem(
            settingsViewModel = settingsViewModel,
            onManagerPrereleasesToggle = { homeViewModel.triggerUpdateCheck() }
        )

        // Patcher tuning
        PatcherTuningSection(
            settingsViewModel = settingsViewModel,
            modifier = if (onProcessRuntimeScrollTarget != null) Modifier.onGloballyPositioned { coords ->
                onProcessRuntimeScrollTarget(coords.boundsInParent().top.roundToInt())
            } else Modifier,
            onProcessRuntimePositioned = onProcessRuntimePositioned
        )

        // Expert settings section
        SectionTitle(
            text = stringResource(R.string.settings_advanced_expert),
            icon = Icons.Outlined.Engineering
        )

        SettingsGroup(
            modifier = if (onExpertModeItemPositioned != null || onExpertModeScrollTarget != null)
                Modifier.onGloballyPositioned { coords ->
                    onExpertModeItemPositioned?.invoke(coords.boundsInWindow())
                    onExpertModeScrollTarget?.invoke(coords.boundsInParent().top.roundToInt())
                }
            else Modifier
        ) {
            SettingsSwitchItem(
                checked = useExpertMode,
                onToggle = {
                    if (!useExpertMode) showExpertModeDialog.value = true
                    else settingsViewModel.setExpertMode(false)
                },
                icon = Icons.Outlined.Psychology,
                title = stringResource(R.string.settings_advanced_expert_mode),
                subtitle = stringResource(R.string.settings_advanced_expert_mode_description)
            )
        }

        Crossfade(
            targetState = useExpertMode,
            label = "expert_mode_crossfade"
        ) { expertMode ->
            if (expertMode) {
                Column(verticalArrangement = Arrangement.spacedBy(Defaults.ContentPadding)) {
                    SettingsGroup {
                        // GitHub PAT
                        GitHubPatSettingsItem(
                            currentPat = gitHubPat,
                            currentIncludeInExport = includeGitHubPatInExports,
                            onSave = { pat, include ->
                                settingsViewModel.setGitHubPat(pat, include)
                            }
                        )
                    }

                    // Expert mode notice shown once after enabling
                    if (showExpertModeNotice) {
                        Notice(
                            icon = Icons.Outlined.Info,
                            text = stringResource(R.string.settings_advanced_patch_options_expert_mode_notice),
                            tone = SemanticTone.Warning
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(Defaults.ContentPadding)) {
                    // Patch Options (Simple mode only)
                    SectionTitle(
                        text = stringResource(R.string.settings_advanced_patch_options),
                        icon = Icons.Outlined.Tune
                    )

                    PatchOptionsSection(
                        patchOptionsPrefs = patchOptionsViewModel.patchOptionsPrefs,
                        patchOptionsViewModel = patchOptionsViewModel,
                        homeViewModel = homeViewModel
                    )
                }
            }
        }
    }
}

/**
 * Dialog to confirm enabling Expert mode.
 */
@Composable
private fun ExpertModeConfirmationDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) = ConfirmDialog(
    title = stringResource(R.string.settings_advanced_expert_mode_dialog_title),
    message = stringResource(R.string.settings_advanced_expert_mode_dialog_message),
    primaryText = stringResource(R.string.enable),
    onConfirm = onConfirm,
    onDismiss = onDismiss
)
